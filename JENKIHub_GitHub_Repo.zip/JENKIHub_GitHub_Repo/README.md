# JΞПKI Hub Unified System

GitHub-ready starter folder for the **JΞПKI | Hub Unified System** mobile integration manifest.

## Files

- `manifest.json` — mobile/web app manifest configuration.
- `index.html` — minimal launch page linked to the manifest.
- `README.md` — repository notes.

## Notes

The manifest references `icon.png` at `512x512`. Add your final app icon with that exact filename in the repository root when ready.
